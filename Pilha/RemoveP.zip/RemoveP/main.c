/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: junior
 *
 * Created on 17 de Setembro de 2017, 20:01
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "removep.h"


int main()
{
    pilha *p,*q;
    int qtd, i, cont = 0;
    char caracter, frase[50], aux;
    
    p = criaPilha();
    q = criaPilha();
    
       
     printf("\nInforme uma frase:\t ");
     scanf(" %[^\n]", frase);
     qtd = strlen(frase); /// tamanho da frase 
     printf("Quantidade %d\n", qtd);
     
    for( i= 0; i < qtd; i++)
    {
        push(p, frase[i]); /// mandando para pilha
    }
     printf("topo %c\n", topo(p));
     printf("informe o caracter que deseja retirar:\t");
     setbuf(stdin,NULL);
     //scanf(" %[^\n]", &caracter); // pedindo ao  usuario que mande um caracter
     caracter = 'a'; 
     printf(" %c", caracter);
     for( i= 0; i < qtd; i++)
     {
	     printf("%c1", topo(p));
	      
         if (caracter == topo(p)) 
         {
		   printf("%c2", topo(p));
             aux = pop(p); 
             cont++; // guardando a quantidade de caracteres que tem iguais.
         }
         else
             aux = pop(p);
         push(q,aux);
     }
     printf("%c", topo(p));
     while ( !pilhaVazia(q))
     {
         if( pilhaVazia(p))
         {
             aux = pop(q);
             push( p,aux);
         }
     }
     printf("\nA pilha com elementos removidos e :\n\t");
     while ( !pilhaVazia(q))
     {
         printf(" %c", pop(p));
     }

    return 0;
}

