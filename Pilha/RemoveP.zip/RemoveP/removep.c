/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   removep.c
 * Author: junior
 *
 * Created on 17 de Setembro de 2017, 20:01
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "removep.h"

struct no
{
    char dado;
    struct no *prox;
};

struct pilha
{
     struct no *topo;
};
/// -----------CRIA PILHA----------------
pilha *criaPilha()
{
    pilha *p;
    p = (pilha*) malloc ( sizeof(pilha));
    if ( !p)
    {
        printf("Nao foi possivel alocar memoria \n");
        exit(1);
    }
    p->topo= NULL;
    return p;
}
/// ---------------- PUSH---------------
void push(pilha *p, int elemento)
{
    no *novoNo;
    novoNo =  (no*) malloc( sizeof( no));
    if ( !novoNo)
    {
        printf("Nao foi possivel alocar memoria.\n");
        exit (1);
    }
    novoNo->dado =  elemento;
    novoNo->prox =  p->topo;
    // atualizar o topo da pilha
    p->topo =  novoNo;
    return;
}
///-----------------POP-------------------
int pop(pilha *p)
{
    char dadoAux = '-';
    no *noAux;
    if( p->topo != NULL)// a pilha nao esta vazia
    {
        noAux =  p->topo;
        dadoAux  = p->topo->dado;
        p->topo = p->topo->prox;
        free( noAux);
    }
    return dadoAux;
}
//---------------Função top------------------------
int topo(pilha *p)
{
    char res = '-';
     if( p->topo != NULL)// a pilha nao esta vazia
     {
         res = p->topo->dado;
     }
    return res;
}
/// ------------ESVAZIA-----------------------
void esvazia(pilha *p)
{
     no *noAux; 
    while ( p->topo != NULL)
    {
        noAux = p->topo;
        p->topo =  p->topo->prox;
        free(noAux);
    }
     return ;
}
//----------->>>>>>Esvaziando a Pilha------------
void esvaziaRetornando(pilha *p)
{
    no *noAux; 
    while ( p->topo != NULL)
    {
        noAux = p->topo;
        p->topo =  p->topo->prox;
        printf("\t%c", p->topo->dado);
    }
    
   
}
//------------RETORNA  SE A PILHA ESTA VAZIA--------
 int pilhaVazia(pilha *p)
 {
     return ( p->topo ==NULL);
 }


