/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   removep.h
 * Author: junior
 *
 * Created on 17 de Setembro de 2017, 20:01
 */

#ifndef REMOVEP_H
#define REMOVEP_H
typedef struct pilha pilha;
typedef struct no no;

//CriaPilha (cria a estrutura pilha vazia)
pilha *criaPilha();

//Push (inserir elemento na pilha)
void push(pilha *p, int elemento);

//Pop (remover elemento da pilha)
int pop(pilha *p);

//Topo (mostrar quem está no topo da pilha)
int topo(pilha *p);

//Esvazia (remove todos os elementos da pilha)
void esvazia(pilha *p);

//Esvazia retornando (remove todos os elementos da pilha)
void esvaziaRetornando(pilha *p);

//pilhaVazia (verifica se a pilha está vazia)
int pilhaVazia(pilha *p);



#endif /* REMOVEP_H */

